
<?php

//echo 'haiii';


$arr['markers'] = "[['Delhi', 23.02,72.5],['Palace of Westminster, London', 23.66,72.55],['Palace of Westminster, London', 23.99,75.2]]";
$arr['info_window'] = "[['<div class=".'info_content'.">' + '<h3>Palace of Delhi</h3>' + '<p>The Palace of Westminster is the meeting place of the House of Commons and the House of Lords, the two houses of the Parliament of the United Kingdom. Commonly known as the Houses of Parliament after its tenants.</p>' +'</div>'],['<div class=".'info_content'.">' + '<h3>Palace of Westminster</h3>' + '<p>The Palace of Westminster is the meeting place of the House of Commons and the House of Lords, the two houses of the Parliament of the United Kingdom. Commonly known as the Houses of Parliament after its tenants.</p>' +'</div>'],['<div class=".'info_content'.">' + '<h3>Palace of Westminster</h3>' + '<p>The Palace of Westminster is the meeting place of the House of Commons and the House of Lords, the two houses of the Parliament of the United Kingdom. Commonly known as the Houses of Parliament after its tenants.</p>' +'</div>']]";
//$arr['info_window'] = "[['<div class='info_content'>212</div>'],['<div class='info_content'>' + '<h3>Palace of Westminster</h3>' + '<p>The Palace of Westminster is the meeting place of the House of Commons and the House of Lords, the two houses of the Parliament of the United Kingdom. Commonly known as the Houses of Parliament after its tenants.</p>' +'</div>'],['<div class='info_content'>212</div>']]";

echo json_encode($arr);
exit;
?>
